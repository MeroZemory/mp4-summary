// Tiny inline icon set — Lucide-style strokes, all 24x24 viewBox.
// Use as <Ico name="search" /> or <Ico name="search" lg />

const ICONS = {
  search:    "M21 21l-4.3-4.3M10.5 17a6.5 6.5 0 1 1 0-13 6.5 6.5 0 0 1 0 13Z",
  command:   "M9 6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6Z",
  bookmark:  "M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16Z",
  bulb:      "M9 18h6M10 22h4M12 2a7 7 0 0 0-4 12.7V17h8v-2.3A7 7 0 0 0 12 2Z",
  chat:      "M21 15a2 2 0 0 1-2 2H8l-5 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10Z",
  send:      "m22 2-7 20-4-9-9-4 20-7Z",
  plus:      "M12 5v14M5 12h14",
  x:         "M18 6 6 18M6 6l12 12",
  menu:      "M4 6h16M4 12h16M4 18h16",
  play:      "M6 4l14 8-14 8V4Z",
  pause:     "M6 4h4v16H6zM14 4h4v16h-4z",
  skip_b:    "M19 20 9 12l10-8v16ZM5 19V5",
  skip_f:    "M5 4l10 8-10 8V4ZM19 5v14",
  user:      "M20 21a8 8 0 1 0-16 0M16 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z",
  check:     "m5 12 5 5L20 7",
  chev_d:    "m6 9 6 6 6-6",
  chev_r:    "m9 6 6 6-6 6",
  chev_l:    "m15 6-6 6 6 6",
  copy:      "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2v-2M16 4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4Z",
  list:      "M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01",
  grid:      "M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z",
  doc:       "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Zm0 0v6h6",
  diagram:   "M5 7h4v4H5zM15 7h4v4h-4zM10 17h4v4h-4zM7 11v4h10v-4",
  clock:     "M12 6v6l4 2M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z",
  trash:     "M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6h14ZM10 11v6M14 11v6",
  filter:    "M3 5h18l-7 8v6l-4 2v-8L3 5Z",
  star:      "m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8l-6.2 3.2L7 14.2 2 9.3l6.9-1L12 2Z",
  edit:      "M12 20h9M16.5 3.5a2.1 2.1 0 1 1 3 3L7 19l-4 1 1-4 12.5-12.5Z",
  download:  "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3",
  settings:  "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm7.4-3a7.6 7.6 0 0 0-.1-1.4l2-1.6-2-3.4-2.4.8a7.5 7.5 0 0 0-2.4-1.4L14 2.5h-4l-.4 2.5a7.5 7.5 0 0 0-2.4 1.4l-2.4-.8-2 3.4 2 1.6a7.5 7.5 0 0 0 0 2.8l-2 1.6 2 3.4 2.4-.8a7.5 7.5 0 0 0 2.4 1.4l.4 2.5h4l.4-2.5a7.5 7.5 0 0 0 2.4-1.4l2.4.8 2-3.4-2-1.6c.1-.5.1-.9.1-1.4Z",
  zap:       "M13 2 3 14h8l-1 8 10-12h-8l1-8Z",
  globe:     "M2 12h20M12 2a14 14 0 0 1 0 20M12 2a14 14 0 0 0 0 20M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z",
  folder:    "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z",
  mic:       "M12 2a3 3 0 0 0-3 3v6a3 3 0 1 0 6 0V5a3 3 0 0 0-3-3Zm7 9a7 7 0 0 1-14 0M12 18v4",
  refresh:   "M21 12a9 9 0 1 1-3-6.7M21 4v5h-5",
  arr_r:     "M5 12h14M13 6l6 6-6 6",
  arr_l:     "M19 12H5M11 18l-6-6 6-6",
  pin:       "M12 17v5M9 3h6l-1 6 4 4H6l4-4-1-6Z",
  tag:       "M20 12 12 20l-9-9V3h8l9 9ZM7 7h.01",
  expand:    "M3 9V3h6M21 9V3h-6M3 15v6h6M21 15v6h-6",
  compress:  "M9 3v6H3M15 3v6h6M9 21v-6H3M15 21v-6h6",
  external:  "M14 4h6v6M10 14 21 3M19 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h5",
  sparkle:   "M12 3v6M12 15v6M3 12h6M15 12h6M5 5l4 4M15 15l4 4M5 19l4-4M15 9l4-4",
  history:   "M12 8v4l3 2M3 12a9 9 0 1 0 3-6.7M3 4v5h5",
  brain:     "M9 4a4 4 0 0 0-4 4 3 3 0 0 0-1 5 4 4 0 0 0 1 5 4 4 0 0 0 4 4V4Zm6 16a4 4 0 0 0 4-4 4 4 0 0 0 1-5 3 3 0 0 0-1-5 4 4 0 0 0-4-4v18Z",
};

function Ico({ name, lg, className = '', style }) {
  const d = ICONS[name];
  if (!d) return null;
  return (
    <svg
      className={(lg ? 'ico-lg ' : 'ico ') + className}
      viewBox="0 0 24 24"
      style={style}
    >
      <path d={d} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

window.Ico = Ico;

// Shared shell for all main screens — keeps left sidebar consistent.
const { useState: useStateS } = React;

function HybridShell({ activeNav = 'lectures', activeLectureId, children }) {
  const { SAMPLE_LECTURES } = window.MP4_DATA;
  const [navCollapsed, setNavCollapsed] = useStateS(false);
  const navW = navCollapsed ? 56 : 232;

  const PRIMARY = [
    { k: 'lectures', ico: 'doc', label: '강의' },
    { k: 'insights', ico: 'bulb', label: '학습 노트', badge: 3 },
    { k: 'bookmarks', ico: 'bookmark', label: '북마크' },
    { k: 'domains', ico: 'brain', label: '도메인' },
  ];

  return (
    <div className="ab" style={{ display: 'grid', gridTemplateColumns: `${navW}px 1fr`, height: '100%', transition: 'grid-template-columns 0.18s ease' }}>
      <aside style={{ borderRight: '1px solid var(--border)', background: 'var(--surface)', display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        <div style={{ padding: '12px 12px 6px', display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 22, height: 22, borderRadius: 6, background: 'var(--accent)', color: '#fff', display: 'grid', placeItems: 'center', fontSize: 11, fontWeight: 700, flexShrink: 0 }}>M</div>
          {!navCollapsed && <div style={{ fontSize: 13, fontWeight: 600 }}>MP4 Summary</div>}
          <button onClick={() => setNavCollapsed(v => !v)} className="ab-btn ghost sm" style={{ marginLeft: 'auto', padding: '0 4px' }} title={navCollapsed ? '펼치기' : '접기'}>
            <Ico name={navCollapsed ? 'chev_r' : 'chev_l'} />
          </button>
        </div>

        {!navCollapsed && (
          <div style={{ padding: '4px 12px 10px' }}>
            <div style={{ position: 'relative' }}>
              <Ico name="search" style={{ position: 'absolute', left: 8, top: 8, color: 'var(--text-4)' }} />
              <input placeholder="검색  ⌘K" style={{ width: '100%', height: 28, padding: '0 8px 0 28px', borderRadius: 7, border: '1px solid var(--border)', background: 'var(--surface-2)', fontSize: 12, color: 'var(--text-2)' }} />
            </div>
          </div>
        )}

        <div className="ab-y" style={{ flex: 1, padding: navCollapsed ? '4px 8px 10px' : '0 8px 10px', minHeight: 0 }}>
          {PRIMARY.map(it => (
            <div key={it.k} className={'ab-nav-item ' + (activeNav === it.k ? 'active' : '')} title={it.label} style={{ justifyContent: navCollapsed ? 'center' : 'flex-start', padding: navCollapsed ? '8px 0' : '6px 10px' }}>
              <Ico name={it.ico} />
              {!navCollapsed && <span style={{ flex: 1 }}>{it.label}</span>}
              {!navCollapsed && it.badge && <span className="ab-pill amber" style={{ fontSize: 9, padding: '0 6px' }}>{it.badge}</span>}
            </div>
          ))}

          {!navCollapsed && activeNav === 'lectures' && (
            <>
              <div style={{ padding: '12px 8px 4px', fontSize: 10, color: 'var(--text-4)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600 }}>제약·생의학</div>
              {SAMPLE_LECTURES.filter(l => l.domain === 'pharmaceutical').map(l => (
                <div key={l.id} className={'ab-nav-item ' + (l.id === activeLectureId ? 'active' : '')} style={{ alignItems: 'flex-start', padding: '7px 10px' }}>
                  <div className="dot" style={{ marginTop: 6 }} />
                  <div style={{ minWidth: 0, flex: 1 }}>
                    <div style={{ fontSize: 12, fontWeight: l.id === activeLectureId ? 600 : 500, lineHeight: 1.4, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{l.title}</div>
                    <div style={{ fontSize: 10, color: 'var(--text-4)', marginTop: 2 }} className="mono">{l.duration} · {l.bookmarks}bm · {l.notes}n</div>
                  </div>
                </div>
              ))}
              <div style={{ padding: '14px 8px 4px', fontSize: 10, color: 'var(--text-4)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600 }}>Finance</div>
              {SAMPLE_LECTURES.filter(l => l.domain === 'finance').slice(0,2).map(l => (
                <div key={l.id} className="ab-nav-item" style={{ alignItems: 'flex-start', padding: '7px 10px' }}>
                  <div className="dot" style={{ marginTop: 6 }} />
                  <div style={{ minWidth: 0, flex: 1 }}>
                    <div style={{ fontSize: 12, lineHeight: 1.4, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{l.title}</div>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>

        <div style={{ padding: '8px 10px', borderTop: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 8, justifyContent: navCollapsed ? 'center' : 'flex-start' }}>
          <div style={{ width: 22, height: 22, borderRadius: 6, background: 'var(--surface-3)', display: 'grid', placeItems: 'center', fontSize: 10, fontWeight: 600, color: 'var(--text-2)' }}>JK</div>
          {!navCollapsed && (
            <>
              <div style={{ fontSize: 12, color: 'var(--text-2)', flex: 1, minWidth: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>김지오</div>
              <Ico name="settings" style={{ color: 'var(--text-4)' }} />
            </>
          )}
        </div>
      </aside>

      <div style={{ minWidth: 0, display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
        {children}
      </div>
    </div>
  );
}

// Common page header (top bar inside the main pane) — used by Home/Insights/Domains for consistency.
function HybridPageHeader({ title, ico, badges, right }) {
  return (
    <div style={{ padding: '12px 24px', borderBottom: '1px solid var(--border)', background: 'var(--surface)', display: 'flex', alignItems: 'center', gap: 12 }}>
      {ico && <Ico name={ico} lg />}
      <div style={{ fontSize: 14, fontWeight: 600 }}>{title}</div>
      {badges && <div style={{ display: 'flex', gap: 6 }}>{badges}</div>}
      {right && <div style={{ marginLeft: 'auto', display: 'flex', gap: 6, alignItems: 'center' }}>{right}</div>}
    </div>
  );
}

window.HybridShell = HybridShell;
window.HybridPageHeader = HybridPageHeader;

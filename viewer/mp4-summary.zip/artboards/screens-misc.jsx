// Lecture list (home), login, learning insights, domain manager — bundled

function ScreenHome() {
  const { SAMPLE_LECTURES } = window.MP4_DATA;
  const grouped = { pharmaceutical: [], finance: [] };
  SAMPLE_LECTURES.forEach(l => grouped[l.domain]?.push(l));

  return (
    <HybridShell activeNav="lectures">
      <HybridPageHeader
        title="강의 라이브러리"
        ico="doc"
        badges={<span className="ab-pill">23개 · 5.2시간</span>}
        right={<>
          <div style={{ position: 'relative', width: 280 }}>
            <Ico name="search" style={{ position: 'absolute', left: 10, top: 8, color: 'var(--text-4)' }} />
            <input placeholder="강의·전사·노트 통합 검색  ⌘K" style={{ width: '100%', height: 30, padding: '0 10px 0 32px', borderRadius: 8, border: '1px solid var(--border)', background: 'var(--surface-2)', fontSize: 12 }} />
          </div>
          <button className="ab-btn primary"><Ico name="plus" /> 영상 업로드</button>
        </>}
      />

      {/* Body */}
      <div className="ab-y" style={{ flex: 1, padding: '24px 32px 60px' }}>
        {/* Stat row */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 32 }}>
          {[
            { label: '총 강의', val: '23', sub: '5.2시간', ico: 'doc', tone: 'var(--accent)' },
            { label: '완독률', val: '68%', sub: '15편 완료', ico: 'check', tone: 'var(--indigo)' },
            { label: '북마크', val: '47', sub: '5색', ico: 'bookmark', tone: 'var(--amber)' },
            { label: '학습 노트', val: '124', sub: '8 대기', ico: 'bulb', tone: 'var(--rose)' },
          ].map((s, i) => (
            <div key={i} className="ab-card" style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 36, height: 36, borderRadius: 9, background: 'rgba(13,148,136,0.08)', color: s.tone, display: 'grid', placeItems: 'center' }}>
                <Ico name={s.ico} lg />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{s.label}</div>
                <div style={{ fontSize: 22, fontWeight: 700, lineHeight: 1.2, marginTop: 2 }}>{s.val}</div>
              </div>
              <div style={{ fontSize: 11, color: 'var(--text-4)' }}>{s.sub}</div>
            </div>
          ))}
        </div>

        {/* Continue watching */}
        <div style={{ marginBottom: 28 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 12 }}>
            <h2 style={{ fontSize: 13, fontWeight: 700, margin: 0, textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-2)' }}>이어서 보기</h2>
            <span className="mono" style={{ fontSize: 11, color: 'var(--text-4)' }}>2개</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            {[SAMPLE_LECTURES[0], SAMPLE_LECTURES[1]].map(l => (
              <div key={l.id} className="ab-card" style={{ padding: 16, display: 'flex', gap: 14 }}>
                <div className="ab-ph" style={{ width: 100, height: 64, flexShrink: 0, fontSize: 10 }}>thumbnail</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', gap: 6, marginBottom: 6 }}>
                    <span className="ab-pill accent" style={{ fontSize: 10 }}>{l.domain}</span>
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 600, lineHeight: 1.4, marginBottom: 4 }}>{l.title}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)', display: 'flex', gap: 8 }} className="mono">
                    <span>{l.duration}</span>
                    <span>·</span>
                    <span>{l.bookmarks} bm</span>
                    <span>·</span>
                    <span>{l.notes} notes</span>
                  </div>
                  <div style={{ marginTop: 10, height: 4, background: 'var(--surface-3)', borderRadius: 2, overflow: 'hidden' }}>
                    <div style={{ width: l.progress + '%', height: '100%', background: l.progress === 100 ? 'var(--text-3)' : 'var(--accent)' }} />
                  </div>
                  <div style={{ fontSize: 10, color: 'var(--text-4)', marginTop: 4 }}>{l.progress === 100 ? '완료' : l.progress + '% · ' + l.updated}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Domain groups */}
        {[
          { id: 'pharmaceutical', label: '제약·생의학', tint: 'var(--accent-tint)' },
          { id: 'finance', label: 'Finance · 거시경제', tint: 'rgba(79,70,229,0.08)' },
        ].map(g => (
          <div key={g.id} style={{ marginBottom: 28 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <h2 style={{ fontSize: 13, fontWeight: 700, margin: 0, textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-2)' }}>{g.label}</h2>
              <span className="mono" style={{ fontSize: 11, color: 'var(--text-4)' }}>{grouped[g.id].length}개</span>
              <button className="ab-btn ghost sm" style={{ marginLeft: 'auto', fontSize: 11 }}><Ico name="filter" /> 필터</button>
              <div style={{ display: 'inline-flex', background: 'var(--surface-2)', borderRadius: 8, padding: 2 }}>
                <button className="ab-btn ghost sm" style={{ background: 'var(--surface)', boxShadow: 'var(--shadow-sm)', padding: '0 6px' }}><Ico name="list" /></button>
                <button className="ab-btn ghost sm" style={{ padding: '0 6px' }}><Ico name="grid" /></button>
              </div>
            </div>

            <div className="ab-card" style={{ overflow: 'hidden' }}>
              {/* table header */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 80px 80px 80px 80px 100px', gap: 16, padding: '8px 16px', fontSize: 10, color: 'var(--text-4)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600, borderBottom: '1px solid var(--border)', background: 'var(--surface-2)' }}>
                <div>강의</div>
                <div style={{ textAlign: 'right' }}>길이</div>
                <div style={{ textAlign: 'right' }}>북마크</div>
                <div style={{ textAlign: 'right' }}>노트</div>
                <div style={{ textAlign: 'right' }}>진행률</div>
                <div style={{ textAlign: 'right' }}>업데이트</div>
              </div>
              {grouped[g.id].map((l, i) => (
                <div key={l.id} style={{ display: 'grid', gridTemplateColumns: '1fr 80px 80px 80px 80px 100px', gap: 16, padding: '12px 16px', fontSize: 13, borderBottom: i < grouped[g.id].length - 1 ? '1px solid var(--border)' : 'none', alignItems: 'center' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <Ico name="play" style={{ color: 'var(--text-4)' }} />
                    <span style={{ fontWeight: 500 }}>{l.title}</span>
                  </div>
                  <div style={{ textAlign: 'right' }} className="mono ab-muted">{l.duration}</div>
                  <div style={{ textAlign: 'right' }} className="mono ab-muted">{l.bookmarks}</div>
                  <div style={{ textAlign: 'right' }} className="mono ab-muted">{l.notes}</div>
                  <div style={{ textAlign: 'right', display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 6 }}>
                    <div style={{ width: 40, height: 4, background: 'var(--surface-3)', borderRadius: 2, overflow: 'hidden' }}>
                      <div style={{ width: l.progress + '%', height: '100%', background: l.progress === 100 ? 'var(--text-3)' : 'var(--accent)' }} />
                    </div>
                    <span className="mono" style={{ fontSize: 10, color: 'var(--text-4)', minWidth: 28 }}>{l.progress}%</span>
                  </div>
                  <div style={{ textAlign: 'right', fontSize: 11, color: 'var(--text-4)' }}>{l.updated}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </HybridShell>
  );
}

function ScreenLogin() {
  return (
    <div className="ab" style={{ height: '100%', display: 'grid', gridTemplateColumns: '1fr 1fr' }}>
      {/* Left brand panel */}
      <div style={{ background: '#0f1410', color: '#f5f5f4', padding: '48px 56px', display: 'flex', flexDirection: 'column', position: 'relative', overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 28, height: 28, borderRadius: 7, background: 'var(--accent)', display: 'grid', placeItems: 'center', fontSize: 13, fontWeight: 700 }}>M</div>
          <div style={{ fontSize: 14, fontWeight: 600 }}>MP4 Summary</div>
        </div>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <div style={{ fontSize: 32, fontWeight: 700, lineHeight: 1.2, letterSpacing: '-0.02em', maxWidth: 420, fontFamily: 'var(--font-serif)' }}>
            강의 영상을<br />
            <span style={{ color: 'var(--accent)' }}>읽을 수 있는 코퍼스</span>로.
          </div>
          <div style={{ marginTop: 18, fontSize: 14, color: '#a8a29e', lineHeight: 1.7, maxWidth: 380 }}>
            MP4 한 편을 자동 전사·교정·요약하고, 직접 질문할 수 있는 살아 있는 학습 자산으로 만들어 줍니다.
          </div>
          <div style={{ marginTop: 24, display: 'flex', gap: 16 }}>
            {[
              { v: '8', l: '요약 모듈' },
              { v: '4', l: '도메인 프롬프트' },
              { v: '0.45', l: 'HyQE 임계값' },
            ].map((s, i) => (
              <div key={i}>
                <div style={{ fontSize: 22, fontWeight: 700, color: 'var(--accent)' }}>{s.v}</div>
                <div style={{ fontSize: 11, color: '#78716c' }}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>
        {/* decorative */}
        <div style={{ position: 'absolute', right: -80, top: -80, width: 280, height: 280, borderRadius: '50%', background: 'radial-gradient(circle, rgba(13,148,136,0.25), transparent 70%)' }} />
      </div>

      {/* Right form */}
      <div style={{ background: 'var(--surface)', padding: '48px 64px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
        <div style={{ maxWidth: 360 }}>
          <div style={{ fontSize: 11, color: 'var(--text-4)', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 600 }}>로그인</div>
          <h1 style={{ fontSize: 22, fontWeight: 700, margin: '6px 0 24px', letterSpacing: '-0.01em' }}>다시 만나서 반가워요</h1>

          <button className="ab-btn" style={{ width: '100%', height: 38, justifyContent: 'center' }}>
            <svg width="16" height="16" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09Z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.99.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23Z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09 0-.73.13-1.43.35-2.09V7.07H2.18a11 11 0 0 0 0 9.86l3.66-2.84Z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38Z"/></svg>
            Google로 계속하기
          </button>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '20px 0', fontSize: 11, color: 'var(--text-4)' }}>
            <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
            또는 이메일로
            <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
          </div>

          <label style={{ display: 'block', marginBottom: 12 }}>
            <div style={{ fontSize: 11, fontWeight: 500, color: 'var(--text-2)', marginBottom: 4 }}>이메일</div>
            <input value="merozemory@gmail.com" readOnly style={{ width: '100%', height: 36, padding: '0 12px', borderRadius: 7, border: '1px solid var(--border)', background: 'var(--surface-2)', fontSize: 13 }} />
          </label>
          <label style={{ display: 'block', marginBottom: 18 }}>
            <div style={{ fontSize: 11, fontWeight: 500, color: 'var(--text-2)', marginBottom: 4, display: 'flex', justifyContent: 'space-between' }}>
              <span>비밀번호</span>
              <span style={{ color: 'var(--accent)', cursor: 'pointer', fontWeight: 500 }}>잊으셨나요?</span>
            </div>
            <input type="password" value="••••••••••" readOnly style={{ width: '100%', height: 36, padding: '0 12px', borderRadius: 7, border: '1px solid var(--accent)', background: 'var(--surface)', fontSize: 13, outline: '2px solid rgba(13,148,136,0.15)', outlineOffset: 1 }} />
          </label>
          <button className="ab-btn primary" style={{ width: '100%', height: 38, justifyContent: 'center', fontSize: 13 }}>로그인 →</button>

          <div style={{ marginTop: 16, fontSize: 12, color: 'var(--text-3)', textAlign: 'center' }}>
            처음이신가요? <span style={{ color: 'var(--accent)', fontWeight: 500, cursor: 'pointer' }}>회원가입</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function ScreenInsights() {
  const { SAMPLE_INSIGHTS } = window.MP4_DATA;
  return (
    <HybridShell activeNav="insights">
      <HybridPageHeader
        title="학습 노트"
        ico="bulb"
        badges={<span className="ab-pill amber">3개 검토 대기</span>}
        right={<>
          <button className="ab-btn ghost sm"><Ico name="filter" /> 태그</button>
          <button className="ab-btn primary"><Ico name="check" /> 모두 승인</button>
        </>}
      />

      <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr', flex: 1, minHeight: 0 }}>
        {/* Left filter rail */}
        <aside style={{ borderRight: '1px solid var(--border)', padding: '16px 12px', background: 'var(--surface)' }}>
          <div style={{ fontSize: 10, color: 'var(--text-4)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600, padding: '4px 8px', marginBottom: 4 }}>상태</div>
          {[
            { l: '대기 중', n: 3, ico: 'clock', active: true },
            { l: '승인됨', n: 18, ico: 'check' },
            { l: '병합', n: 5, ico: 'tag' },
            { l: '무시', n: 2, ico: 'x' },
          ].map((s, i) => (
            <div key={i} className={'ab-nav-item ' + (s.active ? 'active' : '')}>
              <Ico name={s.ico} />
              <span style={{ flex: 1 }}>{s.l}</span>
              <span style={{ fontSize: 10, color: 'var(--text-4)' }} className="mono">{s.n}</span>
            </div>
          ))}
          <div style={{ fontSize: 10, color: 'var(--text-4)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600, padding: '14px 8px 4px' }}>태그</div>
          {['GPCR', 'AlphaFold', 'ADMET', '임상시험', '타깃 식별', '가상 스크리닝'].map(t => (
            <div key={t} style={{ padding: '4px 8px', fontSize: 12, color: 'var(--text-2)' }}># {t}</div>
          ))}
        </aside>

        {/* Card list */}
        <div className="ab-y" style={{ minHeight: 0, padding: '20px 24px 60px' }}>
          {SAMPLE_INSIGHTS.map((it, i) => (
            <div key={it.id} className="ab-card" style={{ padding: 16, marginBottom: 10 }}>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 8 }}>
                <span className="ab-pill" style={{ fontSize: 10 }}>
                  {it.status === 'pending' && <><Ico name="clock" /> 대기</>}
                  {it.status === 'merge' && <><Ico name="tag" /> 병합 후보</>}
                  {it.status === 'accepted' && <span style={{ color: 'var(--accent-deep)' }}><Ico name="check" /> 승인됨</span>}
                </span>
                <span style={{ fontSize: 11, color: 'var(--text-4)' }}>· {it.source}</span>
                <div style={{ marginLeft: 'auto', display: 'flex', gap: 4 }}>
                  <button className="ab-btn ghost sm" style={{ padding: '0 6px' }}><Ico name="edit" /></button>
                  <button className="ab-btn ghost sm" style={{ padding: '0 6px' }}><Ico name="x" /></button>
                  <button className="ab-btn primary sm">승인</button>
                </div>
              </div>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>{it.q}</div>
              <div style={{ fontSize: 13, color: 'var(--text-3)', lineHeight: 1.7 }}>{it.a}</div>
              {it.mergeWith && (
                <div style={{ marginTop: 8, padding: '6px 10px', background: 'rgba(217,119,6,0.06)', borderRadius: 6, fontSize: 11, color: '#92400e' }}>
                  <Ico name="tag" /> 기존 노트와 병합: <em>"{it.mergeWith}"</em>
                </div>
              )}
              <div style={{ marginTop: 8, display: 'flex', gap: 6 }}>
                {it.tags.map(t => <span key={t} className="ab-pill" style={{ fontSize: 10 }}># {t}</span>)}
              </div>
            </div>
          ))}
        </div>
      </div>
    </HybridShell>
  );
}

function ScreenDomains() {
  return (
    <HybridShell activeNav="domains">
      <HybridPageHeader
        title="도메인 프롬프트"
        ico="brain"
        badges={<span className="ab-pill">HyQE 자동 검출 · 임계값 0.45</span>}
        right={<button className="ab-btn primary"><Ico name="plus" /> 도메인 추가</button>}
      />
      <div className="ab-y" style={{ flex: 1, padding: '24px 32px 60px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, minHeight: 0, alignContent: 'flex-start' }}>
        {[
          { id: 'pharmaceutical', label: '제약·생의학', kw: ['drug', 'GPCR', 'protein', 'ADMET', 'kinase', 'IND', 'AlphaFold', 'docking', 'screening', 'efficacy', 'in vivo', 'pharmacokinetic'], lectures: 14, tone: 'var(--accent)', match: 0.86, active: true },
          { id: 'finance', label: 'Finance · 거시경제', kw: ['금리', '국채', '달러', '인플레이션', '환율', 'M2', 'Fed', '유동성', '코스피', '원화', 'stablecoin', '금'], lectures: 12, tone: 'var(--indigo)', match: 0.78 },
          { id: 'generic', label: 'Generic (폴백)', kw: [], lectures: 0, tone: 'var(--text-3)', fallback: true },
          { id: 'new', label: '도메인 추가하기', isNew: true },
        ].map(d => d.isNew ? (
          <div key={d.id} className="ab-card" style={{ padding: 24, border: '1px dashed var(--border-2)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 8, color: 'var(--text-3)', cursor: 'pointer', minHeight: 200 }}>
            <Ico name="plus" lg />
            <div style={{ fontSize: 13, fontWeight: 500 }}>새 도메인 추가</div>
            <div style={{ fontSize: 11, textAlign: 'center', maxWidth: 240 }}>system.md / user.md 작성 + 키워드 30~40개 등록 → 자동 임베딩</div>
          </div>
        ) : (
          <div key={d.id} className="ab-card" style={{ padding: 18, position: 'relative', borderColor: d.active ? d.tone : 'var(--border)', borderWidth: d.active ? 1.5 : 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: d.tone }} />
              <div style={{ fontSize: 14, fontWeight: 600 }}>{d.label}</div>
              {d.fallback && <span className="ab-pill" style={{ fontSize: 10 }}>폴백</span>}
              {d.active && <span className="ab-pill accent" style={{ fontSize: 10 }}>현재 강의 매칭 · {d.match}</span>}
              <div style={{ marginLeft: 'auto', display: 'flex', gap: 4 }}>
                <button className="ab-btn ghost sm" style={{ padding: '0 6px' }}><Ico name="edit" /></button>
                <button className="ab-btn ghost sm" style={{ padding: '0 6px' }}><Ico name="settings" /></button>
              </div>
            </div>
            <div style={{ fontSize: 11, color: 'var(--text-4)' }} className="mono">prompts/{d.id}/ · {d.lectures}개 강의</div>

            <div style={{ marginTop: 14 }}>
              <div style={{ fontSize: 10, color: 'var(--text-4)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600, marginBottom: 6 }}>대표 키워드 ({d.kw.length}/40)</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                {d.kw.length === 0 ? (
                  <span style={{ fontSize: 11, color: 'var(--text-4)' }}>키워드 없음 — 모든 미매칭 영상에 사용됨</span>
                ) : d.kw.map(k => <span key={k} className="ab-pill" style={{ fontSize: 10 }}>{k}</span>)}
              </div>
            </div>

            {!d.fallback && (
              <div style={{ marginTop: 14, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                <div style={{ padding: '8px 10px', borderRadius: 6, background: 'var(--surface-2)' }}>
                  <div style={{ fontSize: 10, color: 'var(--text-4)' }}>system.md</div>
                  <div style={{ fontSize: 11, color: 'var(--text-2)', marginTop: 2 }} className="mono">214 lines · 7.2 KB</div>
                </div>
                <div style={{ padding: '8px 10px', borderRadius: 6, background: 'var(--surface-2)' }}>
                  <div style={{ fontSize: 10, color: 'var(--text-4)' }}>user.md</div>
                  <div style={{ fontSize: 11, color: 'var(--text-2)', marginTop: 2 }} className="mono">82 lines · 2.4 KB</div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </HybridShell>
  );
}

window.ScreenHome = ScreenHome;
window.ScreenLogin = ScreenLogin;
window.ScreenInsights = ScreenInsights;
window.ScreenDomains = ScreenDomains;

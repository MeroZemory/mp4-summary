// Shared sample data for all artboards

const SAMPLE_LECTURES = [
  {
    id: 'drug-discovery',
    title: 'Drug discovery and development',
    domain: 'pharmaceutical',
    duration: '00:48:32',
    chapters: 7,
    bookmarks: 4,
    notes: 12,
    chatSessions: 3,
    updated: '2시간 전',
    progress: 68,
  },
  {
    id: 'drug-discovery-2',
    title: 'Drug discovery and development II',
    domain: 'pharmaceutical',
    duration: '00:52:11',
    chapters: 8,
    bookmarks: 2,
    notes: 7,
    chatSessions: 1,
    updated: '어제',
    progress: 32,
  },
  {
    id: 'drug-target',
    title: 'Drug target prediction and drug repositioning',
    domain: 'pharmaceutical',
    duration: '01:12:48',
    chapters: 9,
    bookmarks: 6,
    notes: 18,
    chatSessions: 2,
    updated: '3일 전',
    progress: 100,
  },
  {
    id: 'p1-2',
    title: 'Part1-2강 · 역사 속 돈의 몰락',
    domain: 'finance',
    duration: '00:36:21',
    chapters: 5,
    bookmarks: 3,
    notes: 6,
    chatSessions: 1,
    updated: '1주 전',
    progress: 100,
  },
  {
    id: 'p2-3',
    title: 'Part2-3강 · 달러 가치의 미래',
    domain: 'finance',
    duration: '00:41:09',
    chapters: 6,
    bookmarks: 1,
    notes: 4,
    chatSessions: 0,
    updated: '2주 전',
    progress: 100,
  },
  {
    id: 'qa-31',
    title: 'QA · 3월 1주 — 국채금리 하락 시나리오',
    domain: 'finance',
    duration: '00:24:55',
    chapters: 4,
    bookmarks: 0,
    notes: 2,
    chatSessions: 1,
    updated: '4일 전',
    progress: 45,
  },
];

const ACTIVE_LECTURE = SAMPLE_LECTURES[0];

const SAMPLE_SEGMENTS = [
  { time: '00:00:08', text: '오늘은 신약 개발 파이프라인 전반을 훑고, 그 안에서 타깃 식별이 어떤 위치를 차지하는지 살펴보겠습니다.' },
  { time: '00:00:24', text: '먼저 신약 개발은 크게 발견(discovery)과 개발(development) 단계로 나뉩니다.' },
  { time: '00:00:41', text: '발견 단계에서 가장 먼저 하는 일이 바로 타깃(target) 식별입니다. 보통 단백질 수용체나 효소가 그 대상이 되죠.' },
  { time: '00:01:02', text: '예를 들어 GPCR 같은 막단백질은 현재 시판되는 약의 약 30% 이상이 작용하는 매우 중요한 타깃 패밀리입니다.' },
  { time: '00:01:28', text: '타깃이 정해지면, 다음으로 그 타깃에 작용할 수 있는 후보 화합물(lead compound)을 찾기 시작합니다.' },
  { time: '00:01:55', text: '여기서 등장하는 게 high-throughput screening, 즉 HTS입니다. 수십만 개의 화합물 라이브러리를 한꺼번에 스크리닝하는 방식이죠.' },
  { time: '00:02:21', text: '최근에는 AI 기반 가상 스크리닝(virtual screening)이 HTS를 빠르게 대체하고 있습니다.' },
  { time: '00:02:48', text: '대표적으로 AlphaFold 이후에 단백질 구조 예측이 거의 실험 수준에 가까워졌고, 도킹 시뮬레이션이 더 신뢰할 만해졌습니다.' },
  { time: '00:03:12', text: '그렇게 발견된 후보 물질을 hit이라고 부르고, 이걸 다듬는 과정을 hit-to-lead라고 합니다.' },
  { time: '00:03:38', text: '여기서 ADMET — 흡수, 분포, 대사, 배설, 독성 — 프로파일을 같이 봅니다.' },
];

const SAMPLE_CONCEPTS = [
  { term: 'Target Identification', kor: '타깃 식별', firstMention: '00:00:41', desc: '약물이 결합할 단백질·수용체·효소를 찾는 단계.' },
  { term: 'GPCR', kor: 'G단백질 결합 수용체', firstMention: '00:01:02', desc: '시판 약물의 30% 이상이 작용하는 핵심 막단백질 패밀리.' },
  { term: 'High-Throughput Screening', kor: 'HTS', firstMention: '00:01:55', desc: '수십만 개 화합물 라이브러리를 한 번에 스크리닝.' },
  { term: 'Virtual Screening', kor: '가상 스크리닝', firstMention: '00:02:21', desc: 'AI·도킹 기반 in-silico 스크리닝.' },
  { term: 'AlphaFold', kor: '알파폴드', firstMention: '00:02:48', desc: '딥러닝 단백질 구조 예측 모델.' },
  { term: 'ADMET', kor: '흡수·분포·대사·배설·독성', firstMention: '00:03:38', desc: '약물성 평가의 5가지 핵심 지표.' },
  { term: 'Hit-to-Lead', kor: '히트-투-리드', firstMention: '00:03:12', desc: 'Hit 화합물을 다듬어 Lead로 발전시키는 최적화 단계.' },
  { term: 'IND Filing', kor: '임상시험계획 승인 신청', firstMention: '00:18:42', desc: 'Phase 1 임상 직전 FDA 승인 절차.' },
];

const SAMPLE_TIMELINE = [
  { time: '00:00:08', end: '00:04:12', title: '신약 개발 파이프라인 개요', desc: 'Discovery / Development 두 단계와 각 단계의 핵심 마일스톤.' },
  { time: '00:04:12', end: '00:11:30', title: '타깃 식별과 검증', desc: 'GPCR, kinase, ion channel 등 대표 타깃 클래스.' },
  { time: '00:11:30', end: '00:18:42', title: '리드 발굴 — HTS와 가상 스크리닝', desc: 'AlphaFold 이후 in-silico screening의 위상 변화.' },
  { time: '00:18:42', end: '00:26:05', title: '전임상 — ADMET와 동물 시험', desc: 'PK/PD 모델링이 임상 1상 디자인에 미치는 영향.' },
  { time: '00:26:05', end: '00:35:14', title: '임상 1·2·3상 디자인', desc: '각 phase의 목적, 환자 수, 통계 검정력.' },
  { time: '00:35:14', end: '00:43:50', title: '허가 후 시판 — Phase 4', desc: '시판 후 안전성 모니터링과 라벨 확장.' },
  { time: '00:43:50', end: '00:48:32', title: 'Q&A — 바이오시밀러와 ADC의 미래', desc: '항체-약물 접합체(ADC) 시장 전망과 규제 변화.' },
];

const SAMPLE_QA = [
  { q: 'GPCR이 왜 가장 중요한 타깃 패밀리인가?', a: '시판 약물의 30% 이상이 GPCR에 작용하기 때문에, 새로운 GPCR 타깃 발견은 곧장 다수의 약물 개발 기회로 이어진다.', t: '00:01:02' },
  { q: 'AlphaFold 이후 가상 스크리닝의 신뢰도는 어떻게 변했나?', a: '단백질 구조 예측 정확도가 실험 수준에 근접하면서, 도킹 시뮬레이션 기반 가상 스크리닝이 HTS를 대체하는 흐름이 가속됐다.', t: '00:02:48' },
  { q: 'Hit과 Lead의 차이는?', a: 'Hit은 스크리닝에서 1차로 발견된 활성 화합물, Lead는 ADMET 최적화를 거쳐 임상 후보로 발전시킨 화합물이다.', t: '00:03:12' },
];

const SAMPLE_CHAT = [
  { role: 'assistant', content: 'Drug discovery and development 강의 컨텍스트로 대화하고 있어요. 무엇이 궁금하세요?' },
  { role: 'user', content: 'GPCR이 왜 그렇게 중요한 타깃이 되는 건가요? 30%라는 수치 출처가 궁금합니다.' },
  { role: 'assistant', content: '강의 1분 2초 부근에서 강사가 “시판 약물의 약 30% 이상이 GPCR에 작용한다”고 언급합니다. 이 수치는 보통 Sriram & Insel (2018, *Mol Pharmacol*)에서 보고된 약 34% 통계를 인용한 것으로 보입니다.\n\n핵심 이유는:\n\n1. **세포 표면에 발현**되어 약물 접근성이 높음\n2. 7-TM 구조의 conformational change가 풍부 → **알로스테릭 모듈레이터** 설계 여지\n3. 인간 게놈에 800개 이상이 있고, 이 중 절반 이상이 후각 수용체이므로 약물 타깃 후보군이 여전히 많음', refs: [{ time: '00:01:02', label: 'GPCR · 1:02' }] },
  { role: 'user', content: '그럼 알로스테릭 모듈레이터는 강의에서 따로 다루나요?' },
];

const SAMPLE_BOOKMARKS = [
  { time: '00:01:02', color: '#0d9488', note: 'GPCR 30% 통계 — 출처 확인 필요', segText: 'GPCR 같은 막단백질은 현재 시판되는 약의 약 30% 이상이…' },
  { time: '00:02:48', color: '#d97706', note: 'AlphaFold 이후 도킹 신뢰도', segText: 'AlphaFold 이후에 단백질 구조 예측이 거의 실험 수준에…' },
  { time: '00:18:42', color: '#7c3aed', note: 'IND 직전 단계 다시 듣기', segText: 'IND filing이 임상 1상 직전에 들어가게 되는데…' },
  { time: '00:34:55', color: '#e11d48', note: '', segText: '여기서 통계검정력이 80%를 넘어야…' },
];

const SAMPLE_INSIGHTS = [
  { id: '1', q: 'GPCR이 약물 타깃으로 중요한 이유?', a: '시판 약물의 30%+가 작용 / 세포 표면 발현 / conformational change 다양성', tags: ['GPCR', '타깃 식별'], status: 'pending', source: 'Drug discovery · session 2' },
  { id: '2', q: 'AlphaFold가 신약 개발 파이프라인을 어떻게 바꿨나?', a: '구조 예측 정확도 → 도킹 시뮬레이션 신뢰도 → 가상 스크리닝이 HTS 대체', tags: ['AlphaFold', '가상 스크리닝'], status: 'pending', source: 'Drug discovery · session 2' },
  { id: '3', q: 'Hit-to-lead에서 ADMET이 어느 시점에 들어가나?', a: 'Hit 확보 직후, lead 최적화와 병행하여 흡수·분포·대사·배설·독성 프로파일링', tags: ['ADMET', 'Hit-to-Lead'], status: 'merge', mergeWith: 'Hit과 Lead의 차이는?', source: 'Drug discovery · session 1' },
  { id: '4', q: 'Phase 1 임상의 목적은?', a: '주로 안전성·내약성, 약동학(PK) 평가', tags: ['임상시험'], status: 'accepted', source: 'Drug discovery · session 3' },
];

window.MP4_DATA = {
  SAMPLE_LECTURES,
  ACTIVE_LECTURE,
  SAMPLE_SEGMENTS,
  SAMPLE_CONCEPTS,
  SAMPLE_TIMELINE,
  SAMPLE_QA,
  SAMPLE_CHAT,
  SAMPLE_BOOKMARKS,
  SAMPLE_INSIGHTS,
};

// Variant D — Hybrid: A의 사이드바 + B의 reader 본문 + C의 항상 보이는 요약, 약점 제거 버전.
//
// 핵심 결정:
//  • 좌측 사이드바: A에서 가져옴. 단, 접을 수 있음 (icon rail).
//  • 본문: B의 reader-centered max-width 680~720px. 단, 탭 대신 sticky anchor TOC로
//    '요약/전사/ShowMe/노트' 사이를 부드럽게 점프. 모든 모듈이 한 페이지에 있되 인접 섹션으로.
//  • 우측 채팅: A의 항상 노출 채팅 + B의 dismissible 토글. 닫으면 본문이 reader 폭으로 넓어진다.
//  • 상단: C의 메타정보 밀도 (도메인/북마크/노트/세션 카운트) + A의 액션.
//  • 하단 오디오: A의 마커 풍부한 바.

const { useState: useStateH, useRef: useRefH, useEffect: useEffectH } = React;

const HYBRID_TOC = [
  { k: 'overview',   label: 'Overview',     ico: 'sparkle' },
  { k: 'concepts',   label: '핵심 개념',     ico: 'tag' },
  { k: 'timeline',   label: '타임라인',      ico: 'clock' },
  { k: 'showme',     label: 'ShowMe',        ico: 'diagram' },
  { k: 'notes',      label: 'Notes',         ico: 'list' },
  { k: 'qa',         label: 'Q&A',           ico: 'bulb' },
  { k: 'transcript', label: '전사',          ico: 'doc' },
];

function VariantHybrid() {
  const { ACTIVE_LECTURE, SAMPLE_SEGMENTS, SAMPLE_CONCEPTS, SAMPLE_TIMELINE, SAMPLE_BOOKMARKS, SAMPLE_CHAT, SAMPLE_LECTURES, SAMPLE_QA } = window.MP4_DATA;
  const [chatOpen, setChatOpen] = useStateH(true);
  const [activeAnchor, setActiveAnchor] = useStateH('overview');
  const scrollRef = useRefH(null);

  const jumpTo = (k) => {
    const root = scrollRef.current;
    if (!root) return;
    const el = root.querySelector('#section-' + k);
    if (!el) return;
    const top = el.offsetTop - 12;
    root.scrollTo({ top, behavior: 'smooth' });
    setActiveAnchor(k);
  };

  useEffectH(() => {
    const root = scrollRef.current;
    if (!root) return;
    const onScroll = () => {
      const y = root.scrollTop + 60;
      let current = HYBRID_TOC[0].k;
      for (const t of HYBRID_TOC) {
        const el = root.querySelector('#section-' + t.k);
        if (el && el.offsetTop <= y) current = t.k;
      }
      setActiveAnchor(current);
    };
    root.addEventListener('scroll', onScroll, { passive: true });
    return () => root.removeEventListener('scroll', onScroll);
  }, []);

  const chatW = chatOpen ? 360 : 0;

  return (
    <HybridShell activeNav="lectures" activeLectureId={ACTIVE_LECTURE.id}>
      <div style={{ display: 'grid', gridTemplateColumns: `1fr ${chatW}px`, height: '100%', minHeight: 0, transition: 'grid-template-columns 0.18s ease' }}>

      {/* ─── Center reader (with sticky meta + anchor TOC) ─── */}
      <main style={{ display: 'flex', flexDirection: 'column', minWidth: 0, background: 'var(--bg)' }}>
        {/* Top meta bar — C의 밀도 */}
        <div style={{ padding: '12px 24px 10px', borderBottom: '1px solid var(--border)', background: 'var(--surface)', display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: 'var(--text-3)', marginBottom: 3 }}>
              <span>제약·생의학</span>
              <Ico name="chev_r" style={{ width: 11, height: 11 }} />
              <span className="ab-pill accent" style={{ fontSize: 10 }}>auto · 0.86</span>
              <span className="mono" style={{ marginLeft: 6, color: 'var(--text-4)' }}>v3 · GPT-5.5 + Claude Opus 4.7</span>
            </div>
            <div style={{ fontSize: 16, fontWeight: 600, letterSpacing: '-0.01em' }}>{ACTIVE_LECTURE.title}</div>
          </div>
          <div style={{ display: 'flex', gap: 4 }}>
            <button className="ab-btn ghost sm"><Ico name="bookmark" /> 4</button>
            <button className="ab-btn ghost sm"><Ico name="bulb" /> 12</button>
            <button className="ab-btn ghost sm"><Ico name="copy" /></button>
            <button className="ab-btn ghost sm"><Ico name="download" /></button>
            <button className="ab-btn ghost sm"><Ico name="refresh" /></button>
            {!chatOpen && (
              <button className="ab-btn primary sm" onClick={() => setChatOpen(true)}><Ico name="chat" /> 채팅 열기</button>
            )}
          </div>
        </div>

        {/* Sticky anchor TOC — 탭 대신 anchor jump (모든 섹션은 한 페이지에 있음) */}
        <div style={{ position: 'sticky', top: 0, zIndex: 5, padding: '0 24px', borderBottom: '1px solid var(--border)', background: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', gap: 4, height: 36 }}>
          {HYBRID_TOC.map(t => (
            <button key={t.k} onClick={() => jumpTo(t.k)} style={{
              height: 28, padding: '0 10px', display: 'flex', alignItems: 'center', gap: 5,
              fontSize: 12, fontWeight: activeAnchor === t.k ? 600 : 500,
              color: activeAnchor === t.k ? 'var(--accent-deep)' : 'var(--text-3)',
              background: activeAnchor === t.k ? 'var(--accent-tint)' : 'transparent',
              borderRadius: 6, border: 0, cursor: 'pointer',
            }}>
              <Ico name={t.ico} />
              {t.label}
            </button>
          ))}
          <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ display: 'inline-flex', background: 'var(--surface-2)', borderRadius: 6, padding: 2 }}>
              {['GPT-5.5', 'Claude'].map((l, i) => (
                <div key={l} style={{ padding: '2px 8px', fontSize: 11, fontWeight: 500, borderRadius: 4, background: i === 0 ? 'var(--surface)' : 'transparent', color: i === 0 ? 'var(--text-1)' : 'var(--text-4)' }}>{l}</div>
              ))}
            </div>
          </div>
        </div>

        {/* Reader body — B의 max-width + 모든 모듈 한 페이지 */}
        <div ref={scrollRef} className="ab-y" style={{ flex: 1, minHeight: 0 }}>
          <article style={{ maxWidth: 720, margin: '0 auto', padding: '32px 32px 100px' }}>
            {/* Overview */}
            <section style={{ marginBottom: 36 }}>
              <SectionHeading id="overview" label="Overview" ico="sparkle" />
              <h1 style={{ fontSize: 26, fontWeight: 700, lineHeight: 1.25, letterSpacing: '-0.02em', margin: '0 0 14px', fontFamily: 'var(--font-serif)' }}>
                신약 개발 파이프라인 — 타깃 식별부터 시판 후 모니터링까지
              </h1>
              <p style={{ fontSize: 15, lineHeight: 1.85, color: 'var(--text-2)', margin: 0 }}>
                이 강의는 신약 개발의 전 과정을 두 축으로 정리한다. <strong style={{ color: 'var(--text-1)' }}>발견(discovery)</strong> 단계에서는 타깃 식별, 히트 발굴, 리드 최적화가 일어나고, <strong style={{ color: 'var(--text-1)' }}>개발(development)</strong> 단계에서는 전임상과 임상 1·2·3상, 그리고 시판 후 안전성 모니터링이 이루어진다.
              </p>
            </section>

            {/* Concepts */}
            <section style={{ marginBottom: 36 }}>
              <SectionHeading id="concepts" label="핵심 개념" ico="tag" count={SAMPLE_CONCEPTS.length} />
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                {SAMPLE_CONCEPTS.slice(0, 6).map((c, i) => (
                  <div key={i} style={{ padding: '10px 12px', borderRadius: 10, border: '1px solid var(--border)', background: 'var(--surface)' }}>
                    <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                      <span style={{ fontSize: 13, fontWeight: 600 }}>{c.term}</span>
                      <span style={{ fontSize: 11, color: 'var(--text-3)' }}>· {c.kor}</span>
                      <span className="ab-ts" style={{ marginLeft: 'auto' }}>{c.firstMention}</span>
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 4, lineHeight: 1.55 }}>{c.desc}</div>
                  </div>
                ))}
              </div>
            </section>

            {/* Timeline */}
            <section style={{ marginBottom: 36 }}>
              <SectionHeading id="timeline" label="타임라인" ico="clock" count={SAMPLE_TIMELINE.length} />
              <div style={{ position: 'relative' }}>
                <div style={{ position: 'absolute', left: 64, top: 6, bottom: 6, width: 1, background: 'var(--border)' }} />
                {SAMPLE_TIMELINE.slice(0, 5).map((t, i) => (
                  <div key={i} style={{ display: 'flex', gap: 16, padding: '10px 0', position: 'relative' }}>
                    <div style={{ width: 56, fontSize: 11, color: 'var(--amber)', fontFamily: 'var(--font-mono)', paddingTop: 1, textAlign: 'right' }}>{t.time}</div>
                    <div style={{ width: 12, position: 'relative', flexShrink: 0 }}>
                      <div style={{ width: 9, height: 9, borderRadius: '50%', background: 'var(--surface)', border: '2px solid var(--accent)', position: 'absolute', left: -4, top: 5 }} />
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 600 }}>{t.title}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2, lineHeight: 1.6 }}>{t.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* ShowMe */}
            <section style={{ marginBottom: 36 }}>
              <SectionHeading id="showme" label="ShowMe — 의사결정 트리" ico="diagram" />
              <div className="ab-mermaid" style={{ minHeight: 200, position: 'relative' }}>
                <svg viewBox="0 0 720 200" width="100%" style={{ maxWidth: 660 }}>
                  {[
                    { x: 30, y: 80, w: 110, h: 40, label: 'Target ID' },
                    { x: 175, y: 80, w: 110, h: 40, label: 'Hit Discovery' },
                    { x: 320, y: 30, w: 110, h: 40, label: 'HTS' },
                    { x: 320, y: 130, w: 110, h: 40, label: 'Virtual Screen' },
                    { x: 465, y: 80, w: 110, h: 40, label: 'Hit-to-Lead' },
                    { x: 610, y: 80, w: 90, h: 40, label: 'IND' },
                  ].map((b, i) => (
                    <g key={i}>
                      <rect x={b.x} y={b.y} width={b.w} height={b.h} rx="8" fill="#fff" stroke="var(--accent)" strokeWidth="1.4" />
                      <text x={b.x + b.w/2} y={b.y + b.h/2 + 4} textAnchor="middle" fontSize="12" fontFamily="Inter, sans-serif" fill="var(--accent-deep)">{b.label}</text>
                    </g>
                  ))}
                  {['M 140 100 L 175 100','M 285 100 L 320 50','M 285 100 L 320 150','M 430 50 L 465 100','M 430 150 L 465 100','M 575 100 L 610 100'].map((d, i) => (
                    <path key={i} d={d} stroke="#94a3b8" strokeWidth="1.4" fill="none" markerEnd="url(#arrh)" />
                  ))}
                  <defs><marker id="arrh" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#94a3b8" /></marker></defs>
                </svg>
                <button style={{ position: 'absolute', top: 8, right: 8, height: 24, width: 24, borderRadius: 6, border: '1px solid var(--border)', background: '#fff', display: 'grid', placeItems: 'center' }}>
                  <Ico name="expand" />
                </button>
              </div>
            </section>

            {/* Q&A */}
            <section style={{ marginBottom: 36 }}>
              <SectionHeading id="qa" label="Study Guide" ico="bulb" count={SAMPLE_QA.length} />
              {SAMPLE_QA.map((qa, i) => (
                <div key={i} style={{ padding: '14px 0', borderBottom: i < SAMPLE_QA.length - 1 ? '1px solid var(--border)' : 'none' }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                    <span style={{ fontSize: 11, color: 'var(--text-4)', fontFamily: 'var(--font-mono)', flexShrink: 0 }}>Q{i + 1}.</span>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{qa.q}</div>
                    <span className="ab-ts" style={{ marginLeft: 'auto' }}>{qa.t}</span>
                  </div>
                  <div style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.75, marginTop: 6, paddingLeft: 28 }}>{qa.a}</div>
                </div>
              ))}
            </section>

            {/* Transcript — 인라인 (B 스타일) */}
            <section>
              <SectionHeading id="transcript" label="전사" ico="doc" right={
                <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                  <div style={{ display: 'inline-flex', background: 'var(--surface-2)', borderRadius: 6, padding: 2 }}>
                    {['교정', '원본', 'JSON'].map((l, i) => (
                      <div key={l} style={{ padding: '2px 8px', fontSize: 11, fontWeight: 500, borderRadius: 4, background: i === 0 ? 'var(--surface)' : 'transparent', color: i === 0 ? 'var(--text-1)' : 'var(--text-4)' }}>{l}</div>
                    ))}
                  </div>
                  <button className="ab-btn ghost sm" style={{ padding: '0 6px' }}><Ico name="search" /></button>
                </div>
              } />
              <div style={{ borderRadius: 10, border: '1px solid var(--border)', background: 'var(--surface)', padding: '6px 0' }}>
                {SAMPLE_SEGMENTS.slice(0, 8).map((s, i) => {
                  const bm = SAMPLE_BOOKMARKS.find(b => b.time === s.time);
                  return (
                    <div key={i} className="ab-seg" style={{ position: 'relative', background: i === 1 ? 'rgba(13,148,136,0.05)' : 'transparent' }}>
                      {bm && <div style={{ position: 'absolute', left: 6, top: 12, width: 6, height: 6, borderRadius: '50%', background: bm.color }} />}
                      <span className="num">{i + 1}</span>
                      <span className="ts">{s.time}</span>
                      <span className="body">{i === 3 ? <>예를 들어 <mark>GPCR</mark> 같은 막단백질은 현재 시판되는 약의 약 30% 이상이 작용하는 매우 중요한 타깃 패밀리입니다.</> : s.text}</span>
                    </div>
                  );
                })}
                <div style={{ padding: '8px 14px', textAlign: 'center', fontSize: 12, color: 'var(--accent)', cursor: 'pointer' }}>전체 {SAMPLE_SEGMENTS.length * 22}개 세그먼트 보기 →</div>
              </div>
            </section>
          </article>
        </div>

        {/* Audio bottom — A의 마커 풍부 버전 */}
        <div style={{ height: 52, borderTop: '1px solid var(--border)', background: 'var(--surface)', display: 'flex', alignItems: 'center', gap: 12, padding: '0 24px' }}>
          <button style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--accent)', color: '#fff', border: 0, display: 'grid', placeItems: 'center', cursor: 'pointer' }}>
            <Ico name="pause" />
          </button>
          <span className="mono" style={{ fontSize: 11, color: 'var(--text-3)', minWidth: 40 }}>32:48</span>
          <div style={{ flex: 1, height: 4, background: 'var(--surface-3)', borderRadius: 2, position: 'relative' }}>
            <div style={{ position: 'absolute', inset: '0 33% 0 0', background: 'var(--accent)', borderRadius: 2 }} />
            {[10, 24, 38, 72].map((p, i) => (
              <div key={i} style={{ position: 'absolute', left: p + '%', top: -3, width: 2, height: 10, background: ['#0d9488','#d97706','#7c3aed','#e11d48'][i] }} />
            ))}
            <div style={{ position: 'absolute', left: '67%', top: -4, width: 12, height: 12, borderRadius: '50%', background: 'var(--accent)', boxShadow: '0 0 0 3px rgba(13,148,136,0.2)' }} />
          </div>
          <span className="mono" style={{ fontSize: 11, color: 'var(--text-3)', minWidth: 40 }}>48:32</span>
          <button className="ab-btn sm">1.25×</button>
        </div>
      </main>

      {/* ─── Right chat (toggleable) ─── */}
      {chatOpen && (
        <ChatPaneHybrid onClose={() => setChatOpen(false)} />
      )}

      {/* Closed-state floating bubble */}
      {!chatOpen && (
        <button
          onClick={() => setChatOpen(true)}
          style={{ position: 'absolute', right: 20, bottom: 72, width: 44, height: 44, borderRadius: '50%', background: 'var(--accent)', color: '#fff', border: 0, boxShadow: 'var(--shadow-lg)', display: 'grid', placeItems: 'center', cursor: 'pointer' }}
          title="채팅 열기"
        >
          <Ico name="chat" lg />
        </button>
      )}
      </div>
    </HybridShell>
  );
}

function SectionHeading({ id, label, ico, count, right }) {
  return (
    <div id={'section-' + id} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12, scrollMarginTop: 60 }}>
      <Ico name={ico} style={{ color: 'var(--accent)' }} />
      <h2 style={{ fontSize: 12, fontWeight: 700, margin: 0, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>{label}</h2>
      {count !== undefined && <span style={{ fontSize: 11, color: 'var(--text-4)' }} className="mono">{count}</span>}
      <div style={{ flex: 1, height: 1, background: 'var(--border)', marginLeft: 4 }} />
      {right && <div style={{ marginLeft: 8 }}>{right}</div>}
    </div>
  );
}

function ChatPaneHybrid({ onClose }) {
  const { SAMPLE_CHAT } = window.MP4_DATA;
  return (
    <aside style={{ borderLeft: '1px solid var(--border)', background: 'var(--surface)', display: 'flex', flexDirection: 'column', minHeight: 0 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px', borderBottom: '1px solid var(--border)' }}>
        <Ico name="chat" />
        <div style={{ fontSize: 13, fontWeight: 600 }}>AI 채팅</div>
        <span className="ab-pill" style={{ marginLeft: 4, fontSize: 10 }}>Sonnet 4.6</span>
        <button className="ab-btn ghost sm" style={{ marginLeft: 'auto', padding: '0 6px' }} title="새 세션"><Ico name="plus" /></button>
        <button className="ab-btn ghost sm" style={{ padding: '0 6px' }} title="히스토리"><Ico name="history" /></button>
        <button className="ab-btn ghost sm" style={{ padding: '0 4px' }} onClick={onClose} title="닫기"><Ico name="x" /></button>
      </div>

      <div className="ab-y" style={{ flex: 1, padding: '14px 14px 0', minHeight: 0 }}>
        {SAMPLE_CHAT.map((m, i) => (
          <div key={i} style={{ marginBottom: 14 }}>
            {m.role === 'user' ? (
              <div style={{ marginLeft: 'auto', maxWidth: '85%', background: 'var(--accent)', color: '#fff', padding: '8px 12px', borderRadius: '14px 14px 4px 14px', fontSize: 13, lineHeight: 1.6, width: 'fit-content' }}>{m.content}</div>
            ) : (
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4, fontSize: 11, color: 'var(--text-4)' }}>
                  <Ico name="brain" /> Claude
                </div>
                <div style={{ fontSize: 13, lineHeight: 1.7, color: 'var(--text-2)', whiteSpace: 'pre-line' }}>{m.content}</div>
                {m.refs && (
                  <div style={{ marginTop: 8, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    {m.refs.map((r, j) => <span key={j} className="ab-pill amber" style={{ cursor: 'pointer' }}><Ico name="play" /> {r.label}</span>)}
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      <div style={{ padding: 12, borderTop: '1px solid var(--border)' }}>
        <div style={{ background: 'var(--surface-2)', borderRadius: 12, padding: '10px 12px', border: '1px solid var(--border)' }}>
          <div style={{ fontSize: 13, color: 'var(--text-3)', minHeight: 36 }}>강의 컨텍스트로 질문해보세요…</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 6 }}>
            <button className="ab-btn ghost sm" style={{ padding: '0 6px' }}><Ico name="pin" /> 1:02 인용</button>
            <span style={{ fontSize: 10, color: 'var(--text-4)', marginLeft: 'auto' }} className="mono">12.3K / 80K</span>
            <button className="ab-btn primary sm" style={{ padding: '0 10px' }}><Ico name="send" /> 보내기</button>
          </div>
        </div>
      </div>
    </aside>
  );
}

window.VariantHybrid = VariantHybrid;
